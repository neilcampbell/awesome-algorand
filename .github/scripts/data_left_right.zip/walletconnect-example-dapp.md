> This resource is auto indexed by AwesomeAlgo, all credits to walletconnect-example-dapp, for more details refer to https://github.com/algorand/walletconnect-example-dapp

---

# WalletConnect V1 Example Dapp

WalletConnect V1 is being sunset, so it is recommended to look at [WalletConnect](https://github.com/WalletConnect) V2 examples for guidance instead of this repo. 

## Develop

```bash
npm run start
```

## Test

```bash
npm run test
```

## Build

```bash
npm run build
```
